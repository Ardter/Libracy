export default function Export() {
  return (
    <div>
      <h1 className="text-3xl font-semibold mb-4">Export</h1>
      <p>Export your library data here.</p>
    </div>
  );
}