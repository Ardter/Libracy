export default function Loans() {
  return (
    <div>
      <h1 className="text-3xl font-semibold mb-4">Loans</h1>
      <p>Track and manage book loans here.</p>
    </div>
  );
}