export default function Dashboard() {
  return (
    <div>
      <h1 className="text-3xl font-semibold mb-4">Dashboard</h1>
      <p>Welcome to the Library Management System.</p>
    </div>
  );
}