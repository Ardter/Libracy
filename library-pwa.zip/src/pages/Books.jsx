export default function Books() {
  return (
    <div>
      <h1 className="text-3xl font-semibold mb-4">Books</h1>
      <p>Manage all book data here.</p>
    </div>
  );
}